// Mobile menu component
import { useState } from 'react';
import { ThemeToggle } from './ThemeToggle';

export function MobileMenu() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="md:hidden">
      <button 
        onClick={() => setIsOpen(!isOpen)} 
        className="p-2" 
        aria-label="Menu"
      >
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="w-6 h-6">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
        </svg>
      </button>
      
      <div className={`mobile-menu fixed inset-0 z-50 bg-white dark:bg-gray-900 ${isOpen ? 'visible' : 'hidden'}`}>
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <a href="#" className="text-xl font-bold">Aditya Kumar</a>
          <button 
            onClick={() => setIsOpen(false)} 
            className="p-2" 
            aria-label="Close Menu"
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="w-6 h-6">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        <nav className="flex flex-col items-center space-y-8 py-12">
          <a href="#about" onClick={() => setIsOpen(false)} className="text-xl hover:text-blue-600 dark:hover:text-blue-400 transition-colors">About</a>
          <a href="#skills" onClick={() => setIsOpen(false)} className="text-xl hover:text-blue-600 dark:hover:text-blue-400 transition-colors">Skills</a>
          <a href="#projects" onClick={() => setIsOpen(false)} className="text-xl hover:text-blue-600 dark:hover:text-blue-400 transition-colors">Projects</a>
          <a href="#experience" onClick={() => setIsOpen(false)} className="text-xl hover:text-blue-600 dark:hover:text-blue-400 transition-colors">Experience</a>
          <a href="#education" onClick={() => setIsOpen(false)} className="text-xl hover:text-blue-600 dark:hover:text-blue-400 transition-colors">Education</a>
          <a href="#contact" onClick={() => setIsOpen(false)} className="text-xl hover:text-blue-600 dark:hover:text-blue-400 transition-colors">Contact</a>
          <ThemeToggle />
        </nav>
      </div>
    </div>
  );
}
