import { useEffect } from 'react';

// Hook to handle scroll reveal animations
export function useScrollReveal() {
  useEffect(() => {
    const revealElements = document.querySelectorAll('.reveal');
    
    const revealOnScroll = () => {
      const windowHeight = window.innerHeight;
      const revealPoint = 150;
      
      revealElements.forEach((element) => {
        const elementTop = element.getBoundingClientRect().top;
        
        if (elementTop < windowHeight - revealPoint) {
          element.classList.add('active');
        } else {
          element.classList.remove('active');
        }
      });
    };
    
    window.addEventListener('scroll', revealOnScroll);
    // Initial check on load
    revealOnScroll();
    
    return () => window.removeEventListener('scroll', revealOnScroll);
  }, []);
}

// Hook to handle mobile menu
export function useMobileMenu() {
  useEffect(() => {
    const menuButton = document.querySelector('[aria-label="Menu"]');
    const mobileMenu = document.querySelector('.mobile-menu');
    
    if (menuButton && mobileMenu) {
      menuButton.addEventListener('click', () => {
        mobileMenu.classList.toggle('hidden');
        mobileMenu.classList.toggle('visible');
      });
    }
    
    return () => {
      if (menuButton) {
        menuButton.removeEventListener('click', () => {});
      }
    };
  }, []);
}

// Hook to handle skill bar animations
export function useSkillBarAnimation() {
  useEffect(() => {
    const skillBars = document.querySelectorAll('.skill-bar');
    
    const animateSkillBars = () => {
      skillBars.forEach((bar) => {
        const barTop = bar.getBoundingClientRect().top;
        const windowHeight = window.innerHeight;
        
        if (barTop < windowHeight) {
          bar.classList.add('animate');
        }
      });
    };
    
    window.addEventListener('scroll', animateSkillBars);
    // Initial check on load
    animateSkillBars();
    
    return () => window.removeEventListener('scroll', animateSkillBars);
  }, []);
}
